---
name: Apex Finance
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c4c7c8'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c6c6c7'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636565'
  inverse-primary: '#5d5f5f'
  secondary: '#c8c6c8'
  on-secondary: '#303032'
  secondary-container: '#474649'
  on-secondary-container: '#b6b4b7'
  tertiary: '#ffffff'
  on-tertiary: '#003824'
  tertiary-container: '#6ffbbe'
  on-tertiary-container: '#00734e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#e4e2e4'
  secondary-fixed-dim: '#c8c6c8'
  on-secondary-fixed: '#1b1b1d'
  on-secondary-fixed-variant: '#474649'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  numeral-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-margin: 20px
  stack-gap: 16px
  element-gap: 8px
  section-padding: 24px
---

## Brand & Style

This design system is engineered for a premium, high-stakes financial environment where security meets cutting-edge technology. The brand personality is authoritative yet frictionless, utilizing a **Corporate Modern** aesthetic fused with **Glassmorphism**. 

The UI is designed to evoke a sense of "digital luxury"—the feeling of handling high-value assets through a refined, physical-like interface. It leverages deep blacks to maximize OLED contrast, creating a canvas where financial data is the hero. The style mimics native iOS (Cupertino) patterns to ensure immediate familiarity and trust, while the subtle use of translucent layers and backdrop blurs adds depth and sophistication.

## Colors

The palette is strictly dark-mode centric to maintain a premium executive feel. 

- **Pure Black (#000000):** Used for the primary background to provide infinite depth on OLED displays.
- **Grayscale Tiering:** We use a hierarchy of dark grays (`#1C1C1E` for primary containers, `#2C2C2E` for secondary elements) to create structural separation without relying on borders.
- **High-Contrast Primary:** White is used as the primary action color against the dark backdrop, ensuring maximum legibility and a clean "Apple-style" aesthetic.
- **Semantic Accents:** 
    - **Emerald Green:** Used exclusively for growth, gains, and successful states.
    - **Soft Red:** Used for losses, spending, or critical alerts.

## Typography

The system utilizes **Inter** as a highly legible, systematic alternative to San Francisco, ensuring a native feel across all platforms.

- **Numerals:** Financial data is the most critical information. Large balances use `numeral-xl` with heavy weights (`700`) to command attention.
- **Hierarchy:** We use a tight scale. Headlines use slight negative letter spacing to feel "locked" and professional. 
- **Body Text:** Standardized at 17px for primary reading to match iOS HIG, ensuring optimal comfort for long transaction lists.
- **Secondary Info:** Captions and labels use `label-md` with medium weights to maintain clarity at small sizes.

## Layout & Spacing

The system follows a **Fixed Grid** approach for mobile, centered around a 20px safe-margin on the left and right. 

- **Rhythm:** An 8px linear scale is used for all internal padding and margins (8, 16, 24, 32, 48).
- **Cards:** Content cards span the full width of the safe area. Secondary cards (like the "Transfer" avatars) utilize horizontal scrolling (carousels) with a 20px leading offset.
- **Grouped Lists:** Following the iOS "Inset Grouped" style, list items are contained within cards with 16px internal padding.
- **Mobile First:** On mobile, the layout is a single column stack. For tablet/desktop, the layout adopts a 12-column grid, but content remains centered in a max-width container of 1024px to preserve the focused, app-like feel.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layers** and **Backdrop Blurs** rather than traditional heavy shadows.

- **Level 0 (Base):** Pure Black (#000000).
- **Level 1 (Surfaces):** Dark Gray (#1C1C1E). This is the standard card background.
- **Level 2 (Glassmorphism):** Used for navigation bars, floating tab bars, and overlaying "Hero" cards. Apply a `blur(20px)` and `saturate(180%)` to the background, with a 10% white border to simulate light hitting the edge of the glass.
- **Shadows:** When used (primarily for the floating bottom nav), shadows are "Large & Diffused": `0px 20px 40px rgba(0, 0, 0, 0.4)`. No shadows are used on flat surface cards to maintain a clean, integrated look.

## Shapes

The shape language is inspired by the "Squircle" (Continuous Corner) geometry found in Apple hardware and software.

- **Primary Cards:** Use a radius of 28px (`rounded-xl` equivalent in this system).
- **Standard Buttons & Inputs:** Use a radius of 16px.
- **Selection Controls:** Chips and pill-shaped toggles use a full-radius (pill) shape.
- **Avatars:** Circular (50% radius) to contrast against the predominantly rectangular grid.

## Components

### Buttons
- **Primary:** Solid White background with Black text. 16px radius. High-impact.
- **Secondary:** Glass-style (Surface-Gray) with White text. Subtle 1px border.
- **Tertiary/Ghost:** No background, White or Accent colored text.

### Cards & Containers
- Cards should have 24px of internal padding.
- All cards use the 28px corner radius.
- Glass cards should have a subtle top-down linear gradient (e.g., `rgba(255,255,255,0.1)` to `transparent`) to add a sense of physical material.

### Input Fields
- Dark gray backgrounds (#1C1C1E) with no border. 
- Focus state is indicated by a 1px white border or a subtle glow.
- Labels are placed above the field in `label-md`.

### Navigation & Motion
- **Bottom Tab Bar:** A floating glass pod with a high backdrop-blur. Icons should be monochrome (White/Gray).
- **Transitions:** Use "Spring" physics for all transitions (Damping: 0.8, Response: 0.4s). 
- **Hero Shifts:** When tapping a card, it should expand to full screen using a shared-element transition, where the card's radius reduces to 0 as it hits the screen edges.
- **Overlays:** Full-screen modals should slide from the bottom and feature a background dimming effect (70% opacity black).