---
name: Kinetic Noir
colors:
  surface: '#121317'
  surface-dim: '#121317'
  surface-bright: '#38393d'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b1f'
  surface-container: '#1e1f23'
  surface-container-high: '#292a2e'
  surface-container-highest: '#343539'
  on-surface: '#e3e2e7'
  on-surface-variant: '#d0c6ab'
  inverse-surface: '#e3e2e7'
  inverse-on-surface: '#2f3034'
  outline: '#999077'
  outline-variant: '#4d4732'
  surface-tint: '#e9c400'
  primary: '#fff6df'
  on-primary: '#3a3000'
  primary-container: '#ffd700'
  on-primary-container: '#705e00'
  inverse-primary: '#705d00'
  secondary: '#ffb4a4'
  on-secondary: '#601305'
  secondary-container: '#822c1a'
  on-secondary-container: '#ff9f8b'
  tertiary: '#f9f6f5'
  on-tertiary: '#303030'
  tertiary-container: '#dcd9d9'
  on-tertiary-container: '#5f5f5e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe16d'
  primary-fixed-dim: '#e9c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#ffdad3'
  secondary-fixed-dim: '#ffb4a4'
  on-secondary-fixed: '#3e0500'
  on-secondary-fixed-variant: '#7f2a18'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#121317'
  on-background: '#e3e2e7'
  surface-variant: '#343539'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-margin: 20px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  section-gap: 40px
---

## Brand & Style

The design system is a high-octane, premium digital experience tailored for fintech and lifestyle applications. It balances the starkness of **Minimalism** with the high-energy aesthetics of **High-Contrast / Bold** movements. The visual narrative centers on "depth through light"—where the interface feels like a physical object illuminated in a void.

The emotional response is one of confidence, speed, and exclusivity. By utilizing a pure black foundation, the UI eliminates visual noise, allowing the vibrant primary accents to guide the user's focus with surgical precision. The aesthetic is futuristic yet grounded, avoiding heavy skeuomorphism in favor of sharp, matte surfaces and atmospheric glows.

## Colors

The palette is built on a foundation of "True Black" to ensure maximum contrast and energy efficiency on OLED displays. 

- **Liv Yellow (#FFD700):** The primary engine of the UI. Used for critical actions, brand moments, and primary progress indicators.
- **Soft Coral (#FF8A71):** Reserved for interactive highlights, secondary navigation states (like active tabs), and subtle calls to attention that need to sit apart from the primary yellow.
- **Deep Matte Surface:** Containers use a near-black (#0A0A0A) to distinguish themselves from the background without breaking the dark immersion.
- **Typography:** Pure white (#FFFFFF) for primary headers, with a mid-tone grey (#8E8E93) for metadata and supporting text to establish a clear information hierarchy.

## Typography

This design system utilizes **Plus Jakarta Sans** for its modern, geometric clarity and friendly terminals, which soften the aggressive high-contrast palette. 

The type system relies on extreme weight variance to create hierarchy. Headlines are bold and tightly spaced to feel impactful. Body text remains clean and legible with generous line heights. For technical data or micro-copy, we use a tracked-out uppercase label style to inject a sense of premium "instrument-panel" utility.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a focus on "safe-zone" margins for mobile-first consumption. 

- **Mobile:** 4-column grid with 20px side margins and 16px gutters.
- **Desktop/Tablet:** 12-column centered grid with a maximum content width of 1200px.

The spacing rhythm is strictly divisible by 8. Cards and modules should use "stack-md" (16px) for internal padding, while the gap between distinct functional sections should be "section-gap" (40px) to allow the pure black background to act as a natural separator.

## Elevation & Depth

Standard drop shadows are strictly prohibited. Depth is instead conveyed through **Atmospheric Glows** and **Tonal Layering**:

1.  **Z-0 (Background):** Pure #000000.
2.  **Z-1 (Surfaces):** Matte #0A0A0A with a 0.5px border of #FFFFFF at 10% opacity.
3.  **Glow FX:** Elevated components (like active cards) feature a 60px Gaussian blur "under-glow" in either Primary Yellow or Soft Coral at 15% opacity, positioned slightly behind the element to simulate a light source reflecting off the floor.
4.  **Directional Light:** A subtle top-down gradient on cards (from #1A1A1A to #0A0A0A) provides a slight 3D curvature.

## Shapes

The shape language is defined by "Stadium" and "Large Radius" geometry. 

Standard containers and cards utilize a **1rem (16px)** or **1.5rem (24px)** radius to create a soft, tactile feel that contrasts against the sharp typography and high-contrast colors. Small interactive elements like chips and utility buttons use full pill-shaped (rounded-full) corners to signify clickability.

## Components

### Buttons
- **Primary:** Solid Liv Yellow (#FFD700) with Black text. Pill-shaped.
- **Secondary:** Transparent background with the Soft Coral (#FF8A71) border and text. 
- **Ghost:** White text, no background, used for low-priority navigation.

### Cards
Cards are the primary container. They must have a matte black fill (#0A0A0A) and an ultra-thin 0.5px stroke (#FFFFFF, 10% opacity). For special "featured" cards, apply a 2px left-side accent border in Primary Yellow.

### Tabs & Switches
Active states for segmented controls or navigation tabs should use a Soft Coral (#FF8A71) background with black text to differentiate from primary action buttons.

### Input Fields
Inputs are dark-themed with a subtle bottom-only border or a fully enclosed matte-black container. On focus, the border or a subtle outer glow should transition to Primary Yellow.

### Chips & Badges
Small, pill-shaped elements. Use semi-transparent versions of the primary/secondary colors (e.g., Yellow at 15% opacity) with solid-colored text for a "glass" look without the blur.